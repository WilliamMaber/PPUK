/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/public/media/PP.svg":
/*!*********************************!*\
  !*** ./src/public/media/PP.svg ***!
  \*********************************/
/***/ ((module) => {

eval("module.exports = \"data:image/svg+xml;base64,bW9kdWxlLmV4cG9ydHMgPSAiZGF0YTppbWFnZS9zdmcreG1sLCUzY3N2ZyB2aWV3Qm94PSctNTAwMCAtNTAwMCAxMDAwMCAxMDAwMCcgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyUzZSAlM2NjaXJjbGUgcj0nNWUzJy8lM2UgJTNjY2lyY2xlIHI9JzQ1MDAnIGZpbGw9JyUyM2ZmZicvJTNlICUzY3BhdGggZD0nbS0xOTQ0IDE1NjB2LTQyMDdjLTE4Ny0xMi0zNDMgMC00NDEgMjktMjgtNjEgMTQ0LTE1NSA0NDEtMjQ1di04MTBoNDM4djcwMGMxNTc4LTMyNyA0NzI0LTM0NCA0NzQxIDIzODQgMTEgMTkyNi0zNDAxIDE2MzItNDM5MCAyMjU3LTEwNzYgNjc4LTU5MyAyMTEzLTU5MyAyMTEzcy02NTEtMTM0NC0xOTYtMjIyMXptNDM4LTQ2OWM0NjItMzE0IDEyNTUtNjkzIDE0MDgtMTQxOCAzMDgtMTQ1OC02MTktMjA2My0xNDA4LTIyNTN6Jy8lM2UgJTNjL3N2ZyUzZSI=\";\n\n//# sourceURL=webpack://my-webpack-project/./src/public/media/PP.svg?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/public/media/PP.svg");
/******/ 	
/******/ })()
;